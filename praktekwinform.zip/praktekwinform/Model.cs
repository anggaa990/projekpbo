﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Model
    {
        public List<Mahasiswa> daftarMahasiswa = new List<Mahasiswa>
        {
            new Mahasiswa("Halo bang", ":)"),
            new Mahasiswa("Selamat datang ^^ ", "Welcome Tuan")
        };
    }

    public class Mahasiswa
    {
        public string nama, nim;

        public Mahasiswa(string nama, string nim)
        {
            this.nama = nama;
            this.nim = nim;
        }
    }
}

