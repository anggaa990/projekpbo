﻿using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace praktekwinform
{
    public partial class Form2 : Form
    {
        string username;

        Model.Model model = new Model.Model();
        public Form2(string username)
        {
            InitializeComponent();
            this.username = username;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            label1.Text = $"Welcome {this.username} !! ";
            label2.Text = model.daftarMahasiswa[0].nama;
            label3.Text = model.daftarMahasiswa[0].nim;
            label4.Text = model.daftarMahasiswa[1].nama;
            label5.Text = model.daftarMahasiswa[1].nim;

        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }
    }
}
