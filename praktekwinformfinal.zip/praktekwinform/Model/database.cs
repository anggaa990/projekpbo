﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;

namespace praktekwinform.Model
{
    

    public static class Database
    {
        public static string ConnString = "Host=localhost;Port=5432;Username=postgres;Password=nafisa29;Database=donordarah2";
    }
}
